package com.dsrc.view;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import com.dsrc.dao.HibernateUtil;
import com.dsrc.model.Product;

public class ProductScreen 
{
		public int showProductScreen()
		{
			// Add the product Menu..
			Scanner sc=new Scanner(System.in);
			System.out.println("Product Menu\n");
			System.out.println("1. New Product");
		System.out.println("2. Edit Product");
		System.out.println("3. Delete Product");
		System.out.println("4. List Product");
		System.out.println("5. Search Product");
		System.out.println("6. Exit");
		
		System.out.println("Enter your Choice :");
		
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			
			System.out.println("Enter Product ID :");
			int ProId=sc.nextInt();
			System.out.println("Enter Product Name :");
			String ProName=sc.next();
			System.out.println("Enter ProductPrice :");
			String ProPrice=sc.next();
			Product p=new Product(ProId,ProName,ProPrice);
			boolean res=new HibernateUtil().saveProduct(p);
			break;
			
			
		case 2:
			//System.out.println("Enter Product ID :");
			//int ProId2=sc.nextInt();
			System.out.println("Enter Product Name :");
			String ProName2=sc.next();
			//System.out.println("Enter ProductPrice :");
			//String ProPrice2=sc.next();
			Product p2=new Product();
			boolean res2=new HibernateUtil().updateProduct(ProName2);
			
			break;
		case 3:
			
			System.out.println("Enter Product ID :");
			int proid=sc.nextInt();
			
			Product p3=new Product();
			boolean res3=new HibernateUtil().deleteProduct(proid);
			
			
			break;
		case 4:
			
			
			
			Product p4=new Product();
			boolean res4=new HibernateUtil().list();
			
			break;
		
		case 5:
			
			System.out.println("1. By Product Id");
			System.out.println("2. By Name");
			System.out.println("3. By Price range");
			int select=sc.nextInt();
			switch(select)
			{
			case 1 :
			
			System.out.println("Enter Product ID :");
			int id1=sc.nextInt();
			
			boolean res1=new HibernateUtil().searchByID(id1);
			
				break;
			
			case 2:
				
				System.out.println("Enter Product Name :");
				String proname=sc.next();
				
				boolean ress2=new HibernateUtil().searchByName(proname);

				

				break;
			
			case 3:
				
				System.out.println("Enter From Price");
				int pr1=sc.nextInt();
				System.out.println("Enter To Price");
				int pr2=sc.nextInt();
				boolean ress3=new HibernateUtil().searchByRange(pr1, pr2);
				break;
			}
			
			
			
			break;
			
			
				
		case 6:
			break;
		}
		return choice;
}
}