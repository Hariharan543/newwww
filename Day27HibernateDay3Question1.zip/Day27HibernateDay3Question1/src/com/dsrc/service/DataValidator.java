package com.dsrc.service;

import com.dsrc.model.Product;

public class DataValidator 
{
	public boolean validateProduct(Product product)
	{
		// Code to call DAO..
		
		
		return true;
	}
}
