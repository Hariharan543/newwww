package com.dsrc.service;

public class ProductController
{
		public int productManage()
		{
			return 0;
		}
}
