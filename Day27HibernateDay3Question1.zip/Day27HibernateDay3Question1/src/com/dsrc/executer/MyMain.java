package com.dsrc.executer;

import com.dsrc.view.MenuScreen;

public class MyMain 
{
		public static void main(String[] args) 
		{
			MenuScreen ms=new MenuScreen();
			ms.showMenu();
		}
}
