package com.dsrc.dao;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import com.dsrc.model.Product;
import com.dsrc.model.Staff;
import com.dsrc.view.ProductScreen;
import com.dsrc.view.StaffScreen;

public class HibernateUtilStaff 
{
	
	SessionFactory sx=new AnnotationConfiguration().configure().addAnnotatedClass(Staff.class).buildSessionFactory();
	Session s=sx.openSession();
	Transaction t=s.beginTransaction();
	StaffScreen ps=new StaffScreen();
 
	public boolean saveStaff(Staff staff)
	{
		
		
	
		s.save(staff);	
		t.commit();
		System.out.println("Product Added Successfully .");
		
		//ps.showProductScreen();
		
		
		return true;
	}

/*	public boolean updateProduct(Staff staff)
	{
		
		s.save(staff);	
		t.commit();
		System.out.println("Staff updated Successfully .");
		
		ps.showStaffScreen();
		return true;
	}
	
	

	
	
public boolean deleteProduct(int id)
{
	String hql = "DELETE FROM Staff P WHERE P.staffid =?";
	
	
	Query q1 = s.createQuery(hql);

	q1.setInteger(0, id);
	int result = q1.executeUpdate();

	
	System.out.println("Deleted");
	ps.showStaffScreen();

	return true;
}
	
	
*/

}

