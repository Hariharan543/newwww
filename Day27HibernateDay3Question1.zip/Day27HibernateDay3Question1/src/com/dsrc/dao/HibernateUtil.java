package com.dsrc.dao;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.criterion.Restrictions;

import com.dsrc.model.Login;
import com.dsrc.model.Product;
import com.dsrc.view.MenuScreen;
import com.dsrc.view.ProductScreen;

public class HibernateUtil 
{
	SessionFactory sx=new AnnotationConfiguration().configure().addAnnotatedClass(Product.class).buildSessionFactory();
	Session s=sx.openSession();
	Transaction t=s.beginTransaction();
	ProductScreen ps=new ProductScreen();
	
	public boolean checkLogin()
	{
		SessionFactory sx=new AnnotationConfiguration().configure().addAnnotatedClass(Login.class).buildSessionFactory();
		Session session=sx.openSession();
		Transaction transaction=session.beginTransaction();
		
		Criteria c=session.createCriteria(Login.class);
				c.add(Restrictions.eq("user.username",username)).uniqueResult();
		
		MenuScreen ms=new MenuScreen();
		ms.showMenu();
		return true;
		
	}
	
	
	
 
	public boolean saveProduct(Product product)
	{
		
		
	
		s.save(product);	
		t.commit();
		System.out.println("Product Added Successfully .");
		
		ps.showProductScreen();
		
		return true;
	}

	public boolean updateProduct(int productid, int price)
	{
		String hql2 = "UPDATE Product set price = ? WHERE productid =?";
		Query query = s.createQuery(hql2);
	
		query.setInteger(0, price);
		query.setInteger(1, productid);
		
		int result = query.executeUpdate();

		System.out.println("updated");
		ps.showProductScreen();
		return true;
	}
	
	public boolean searchByID(int id1) {
		// TODO Auto-generated method stub
String hql1 = "FROM Product P WHERE P.productid=?";
		
		Query q = s.createQuery(hql1);
		q.setInteger(0, id1);
		
		List results = q.list();
		for(Iterator i=results.iterator();i.hasNext();)
		{
			Product pro=(Product) i.next();
			System.out.println("ProductID   Product Name   Product price" );
			System.out.println("---------------------------------------------");
			System.out.print(pro.getProductid());
			System.out.print("            "+pro.getProductname());
			System.out.println("            "+pro.getPrice());
			System.out.print("-----------------------------------------------");
	
		}	
		ps.showProductScreen();
		return true;
	}
	
	
	public boolean searchByName(String proname) {
		// TODO Auto-generated method stub
String hql1 = "FROM Product P WHERE P.productname=?";
		
		Query q = s.createQuery(hql1);
		q.setString(0, proname);
		
		List results = q.list();
		for(Iterator i=results.iterator();i.hasNext();)
		{
			Product pro=(Product) i.next();
			System.out.println("ProductID   Product Name   Product price" );
			System.out.println("---------------------------------------------");
			System.out.print(pro.getProductid());
			System.out.print("            "+pro.getProductname());
			System.out.println("            "+pro.getPrice());
			System.out.print("-----------------------------------------------");
	
		}	
		ps.showProductScreen();

		
		return true;
	}
	
	
	public boolean searchByRange(int fromPrice,int toPrice)
	{
		String hql3 = "FROM Product P WHERE price between ? and ? ";
		
		Query q3 = s.createQuery(hql3);
	
		q3.setInteger(0, fromPrice);
		q3.setInteger(1, toPrice);
		
		List results3 = q3.list();
		for(Iterator i=results3.iterator();i.hasNext();)
		{
			Product pro=(Product) i.next();
			System.out.println("ProductID   Product Name   Product price" );
			System.out.println("---------------------------------------------");
			System.out.print(pro.getProductid());
			System.out.print("            "+pro.getProductname());
			System.out.println("            "+pro.getPrice());
			System.out.print("-----------------------------------------------");
		}
		ps.showProductScreen();

		return true;
	}

	
public boolean deleteProduct(int id)
{
	String hql = "DELETE FROM Product P WHERE P.productid =?";
	
	
	Query q1 = s.createQuery(hql);

	q1.setInteger(0, id);
	int result = q1.executeUpdate();

	
	System.out.println("Deleted");
	ps.showProductScreen();

	return true;
}
	
	

public boolean list()
{
	List prolist=s.createQuery("FROM Product").list();
	System.out.println("ProductID   Product Name   Product price" );
	System.out.println("---------------------------------------------");
	for(Iterator i=prolist.iterator();i.hasNext();)
	{
		
		Product pro=(Product) i.next();
		
		System.out.print(pro.getProductid());
		System.out.print("            "+pro.getProductname());
		System.out.println("            "+pro.getPrice());
	
		

	}
	System.out.print("-----------------------------------------------");
	ps.showProductScreen();
	return true;
}

public boolean updateProduct(String p2) {
	// TODO Auto-generated method stub
	
	String hql = "update Product p set p.productname=? where p.productid=105";
Query q = s.createQuery(hql);
q.setString(0, p2);
int result = q.executeUpdate();
	
	System.out.println("updated");
	ps.showProductScreen();
	return true;
}
	
	}
	

